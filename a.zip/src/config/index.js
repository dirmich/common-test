import path from 'path'
const __dirname = path.resolve()
const config = {
  common: {
    
    logDir: __dirname + '/logs',
   // secret_key: 'dc95e7a8310f4ec4d8e64ae8071e7ae0199cc747be3911057e',
   secret_key: 'b5c7e0e8d919779dc04d77f129e8f324f06b698d6dfcb5fd2d',
   jwt: {
     // skey: '!LKJLJADFJ@!KJKLF',
     skey: 'zmQ0P370v5FTF99i5',
      expiresIn: '1y',
      issuer: 'auth.highmaru.com',
      algorithm: 'HS256',
    },
    uploadPath: __dirname + '/uploads',
  },
  development: {
    mongohost:
      'mongodb://localhost:27017/pumgen2',    
    redis: 'localhost',
    redis_port: 6379,
    whitelist: ['http://localhost:3101'],
    port: 3100,
  },
  production: {
    mongohost: 'mongodb://database:27017/pumgen2',
    redis: 'redis',
    redis_port: 6379,
    port: 3100,
    // redis: '',
    // redis_port: ,
    // redis_pass: '',
    whitelist: [
      ['https://fronturl'],
    ],
  },
}
const env = process.env.NODE_ENV || 'development'
const exp = {
  dev: env === 'development',
  ...config.common,
  ...config[env],
}
console.log('[ENV]', env) //, { ...config.common, ...config[env] })

export default exp
