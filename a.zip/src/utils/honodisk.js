// src/index.ts
import { createWriteStream } from 'fs'
import { mkdir } from 'fs/promises'
import { join } from 'path'
import { HonoStorage } from './honostorage'
// import { HonoStorage } from '@hono-storage/core'
import { File } from '@web-std/file'
var HonoDiskStorage = class extends HonoStorage {
  constructor(option = {}) {
    const { dest = '/tmp' } = option
    super({
      storage: async (c, files) => {
        console.log('storage')
        await Promise.all(
          files.map(async (file) => {
            const dest2 =
              typeof this.dest === 'function' ? this.dest(c, file) : this.dest
            console.log('mkdir', dest2)
            await mkdir(dest2, { recursive: true })
            if (option.filename) {
              await this.handleDestStorage(
                dest2,
                new File([file], option.filename(c, file))
              )
            } else {
              await this.handleDestStorage(dest2, new File([file], file.name))
            }
          })
        )
      },
    })
    this.dest = dest
  }
  handleDestStorage = async (dest, file) => {
    console.log('handle dest storage')
    const writeStream = createWriteStream(join(dest, file.name))
    const reader = file.stream().getReader()
    while (true) {
      const { done, value } = await reader.read()
      if (done) {
        break
      }
      writeStream.write(value)
    }
    writeStream.end()
  }
}
export { HonoDiskStorage }
