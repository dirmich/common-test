import { S3, S3Client } from '@aws-sdk/client-s3'
import moment from 'moment'
import cfg from '../config'
import awsconfig from '../config/awsconfig.json'
import { HonoDiskStorage } from './honodisk'
import { HonoS3Storage } from './honos3'

let s3 = new S3(awsconfig)
let client = new S3Client(awsconfig)
client.config.region().then((r) => {
  console.log('region', r)
})

const allowedExt = ['.png', '.jpg', '.jpeg', '.bmp']

export const honoUploader = new HonoS3Storage({
  bucket: 'marutrend',
  // key: (_, file) =>
  //   `${file.originalname}-${new Date().getTime()}.${file.extension}`,
  key: ({ userinfo }, file) => {
    // console.log('body id', userinfo.id, file, file.originalname,file.extension)
    if (userinfo.id) {
      const uploadPath = userinfo.id ?? 'dummy'
      // const ext = path.extname(file.originalname)
      const ext = file.extension.trim()
      // console.log(`ext "${ext}",${allowedExt.includes(ext)}`,allowedExt.indexOf(ext))
      if (!allowedExt.includes(ext)) {
        // console.log('ext fail', ext)
        // return callback(new Error('wrong extension'))
        return ''
      }
      // console.log(
      //   `upload to images/${uploadPath}/${moment().format(
      //     'YYYYMMDD_HHmmss'
      //   )}${ext}`
      // )
      return `images/${uploadPath}/${moment().format('YYYYMMDD_HHmmss')}${ext}`
    } else {
      console.log('Invalid key', userinfo.id)
      return `images/none/${moment().format('YYYYMMDD_HHmmss')}${ext}`
    }
  },
  client,
})

export const diskUploader = new HonoDiskStorage({
  dest: cfg.uploadPath,
  filename: (_, file) =>
    `${file.originalname}-${new Date().getTime()}.${file.extension}`,
})
