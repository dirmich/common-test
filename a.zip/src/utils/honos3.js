// src/index.ts
import { getSignedUrl } from '@aws-sdk/s3-request-presigner'

// src/storage.ts
import { PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3'
import { HonoStorage } from './honostorage'
// import { HonoStorage } from '@hono-storage/core'
var SIGN_CONFIG_KEY = 'hono-storage-s3:sign-config'
var SIGNED_URL_KEY = 'signedURLs'
var BaseHonoS3Storage = class {
  storage
  key
  bucket
  params
  s3Repository
  constructor(options, s3Repository) {
    this.storage = new HonoStorage({
      storage: async (c, files) => {
        console.log('storage', files)
        await Promise.all(
          files.map(async (file) => {
            await this.upload(c, file)
          })
        )
      },
    })
    this.key = options.key ?? ((_, file) => file.name)
    this.bucket = options.bucket
    this.params = options.params
    this.s3Repository = s3Repository
  }
  async upload(c, file) {
    const key = this.key(c, file)
    const bucket =
      typeof this.bucket === 'function' ? this.bucket(c, file) : this.bucket
    const isBufferExists = typeof Buffer !== 'undefined'
    const putCommand = new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: isBufferExists ? Buffer.from(await file.arrayBuffer()) : file,
      ContentType: file.type,
      ContentLength: file.size,
      ...this.params,
    })
    const getCommand = new GetObjectCommand({
      Bucket: bucket,
      Key: key,
    })
    const signConfig = c.get(SIGN_CONFIG_KEY) ?? {}
    const sign = signConfig[file.field.name]
    const s3Repository =
      typeof this.s3Repository === 'function'
        ? this.s3Repository(c, file)
        : this.s3Repository
    const ret = await s3Repository.put(putCommand)
    // console.log('ret', ret)
    c.set('url', {
      [file.field.name]: `https://${bucket}.s3.amazonaws.com/${key}`,
    })
    if (sign) {
      const signedURL = await s3Repository.getSingedURL(getCommand, sign)
      const signedURLs = c.get(SIGNED_URL_KEY) ?? {}
      c.set(SIGNED_URL_KEY, {
        ...signedURLs,
        [file.field.name]: (() => {
          const targetSignField = signedURLs[file.field.name] ?? []
          if (
            file.field.type === 'single' ||
            typeof targetSignField === 'string'
          ) {
            return signedURL
          }
          return [...targetSignField, signedURL]
        })(),
      })
    }
  }
  single = (name, options) => {
    return async (c, next) => {
      c.set(SIGNED_URL_KEY, {
        ...(c.get(SIGNED_URL_KEY) ?? {}),
      })
      if (options?.sign) {
        c.set(SIGN_CONFIG_KEY, {
          ...(c.get(SIGN_CONFIG_KEY) ?? {}),
          [name]: options.sign,
        })
      }
      await this.storage.single(name)(c, next)
    }
  }
  multiple = (name, options) => {
    return async (c, next) => {
      c.set(SIGNED_URL_KEY, {
        ...(c.get(SIGNED_URL_KEY) ?? {}),
      })
      if (options?.sign) {
        c.set(SIGN_CONFIG_KEY, {
          ...(c.get(SIGN_CONFIG_KEY) ?? {}),
          [name]: options.sign,
        })
      }
      await this.storage.multiple(name)(c, next)
    }
  }
  fields = (schema) => {
    return async (c, next) => {
      c.set(SIGNED_URL_KEY, {
        ...(c.get(SIGNED_URL_KEY) ?? {}),
      })
      if (Object.keys(schema).some((key) => schema[key].sign)) {
        c.set(SIGN_CONFIG_KEY, {
          ...(c.get(SIGN_CONFIG_KEY) ?? {}),
          ...Object.keys(schema).reduce((acc, key) => {
            if (schema[key].sign) {
              acc[key] = schema[key].sign
            }
            return acc
          }, {}),
        })
      }
      await this.storage.fields(schema)(c, next)
    }
  }
}

// src/index.ts
var S3Repository = class {
  client
  constructor(client) {
    this.client = client
  }
  async put(command) {
    return await this.client.send(command)
  }
  async getSingedURL(command, sign) {
    return await getSignedUrl(this.client, command, sign)
  }
}
var HonoS3Storage = class extends BaseHonoS3Storage {
  constructor(options) {
    const client = options.client
    if (typeof client !== 'function') {
      super(options, new S3Repository(client))
      return
    }
    super(options, (c, file) => new S3Repository(client(c, file)))
  }
}
export { HonoS3Storage }
