// src/file.ts
import { File } from '@web-std/file'
var HonoStorageFile = class extends File {
  field
  constructor(file, field) {
    // console.log('add file ', file.name)
    super([file], file.name)
    this.field = field
    console.log('set name', this.name, field)
  }
  get originalname() {
    const name = this.name
    const lastDot = name.lastIndexOf('.')
    if (lastDot === -1) {
      return name
    }
    return name.substring(0, lastDot)
  }
  get extension() {
    const name = this.name
    const lastDot = name.lastIndexOf('.')
    if (lastDot === -1) {
      return ''
    }
    return name.substring(lastDot)
    // return name.substring(lastDot + 1)
  }
}

// src/error.ts
var HonoStorageError = class extends Error {
  constructor(message) {
    super(message)
    this.name = 'HonoStorageError'
  }
}
var Errors = {
  TooManyFiles: new HonoStorageError('Too many files'),
}

// src/storage.ts
var isFile = (value) => {
  if (typeof value !== 'object' || value === null) return false
  return value instanceof Blob && value.constructor.name === 'File'
}
var FILES_KEY = 'files'
var HonoStorage = class {
  options
  constructor(options) {
    this.options = options ?? {}
  }
  handleSingleStorage = async (c, file, fieldName) => {
    if (this.options.storage) {
      await this.options.storage(c, [
        new HonoStorageFile(file, {
          name: fieldName,
          type: 'single',
        }),
      ])
    }
  }
  handleMultipleStorage = async (c, files, fieldName) => {
    if (this.options.storage) {
      await this.options.storage(
        c,
        files.map(
          (file) =>
            new HonoStorageFile(file, {
              name: fieldName,
              type: 'multiple',
            })
        )
      )
    }
  }
  single = (name, _options) => {
    return async (c, next) => {
      const formData = await c.req.parseBody({ all: true })
      const value = formData[name]
      console.log(
        'handle single storage',
        isFile(value),
        typeof value,
        value.name
      )
      //   if (isFile(value)) {
      await this.handleSingleStorage(c, value, name)
      //   }
      c.set(FILES_KEY, {
        ...c.get(FILES_KEY),
        [name]: value,
      })
      await next()
    }
  }
  multiple = (name, options) => {
    return async (c, next) => {
      const formData = await c.req.parseBody({ all: true })
      const value = formData[name]
      const filedFiles = []
      if (Array.isArray(value)) {
        filedFiles.push(...value.filter(isFile))
      } else if (isFile(value)) {
        filedFiles.push(value)
      }
      if (options?.maxCount && filedFiles.length > options.maxCount) {
        throw new Error('Too many files')
      }
      await this.handleMultipleStorage(c, filedFiles, name)
      c.set(FILES_KEY, {
        ...c.get(FILES_KEY),
        [name]: value,
      })
      await next()
    }
  }
  fields = (schema) => {
    return async (c, next) => {
      const formData = await c.req.parseBody({ all: true })
      const uploader = []
      const files = {}
      for (const name in schema) {
        const value = formData[name]
        const field = schema[name]
        if (field.type === 'multiple') {
          const filedFiles = []
          if (Array.isArray(value)) {
            filedFiles.push(...value.filter(isFile))
          } else if (isFile(value)) {
            filedFiles.push(value)
          }
          if (field.maxCount && filedFiles.length > field.maxCount) {
            throw Errors.TooManyFiles
          }
          uploader.push(this.handleMultipleStorage(c, filedFiles, name))
          files[name] = [value].flat()
          continue
        }
        if (field.type === 'single') {
          if (isFile(value)) {
            uploader.push(this.handleSingleStorage(c, value, name))
          }
          files[name] = value
          continue
        }
      }
      await Promise.all(uploader)
      c.set(FILES_KEY, {
        ...c.get(FILES_KEY),
        ...files,
      })
      await next()
    }
  }
}
export { Errors, FILES_KEY, HonoStorage, HonoStorageError, HonoStorageFile }
