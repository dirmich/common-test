// const registrationToken = "AAAADBaPXIw:APA91bESIFsnXPUWoZnzvv0N3zyvK41jPvPSerImimoIhon658s9UILlJNaeTA1-aNnkuqfa6SKYkYVOA4snmLxaiyEbpupJe4grFdGuqYZoW5XO2xct7tJE1HCpklN1FUjp8pKJrsFN";

var admin = require('firebase-admin')

var serviceAccount = require('../config/remotevalve-firebase-adminsdk-mwqqk-53f87f7b79.json')
// var serviceAccount = require('../config/shuttleb-9a5ac-firebase-adminsdk-5bzdc-b3be4a3d61.json')

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  // databaseURL: 'https://shuttleb-ccfbe.firebaseio.com',
})

const sendMessage = async (registrationToken, title, body) => {
  var payload = {
    notification: {
      title: title,
      body: body,
    },
  }
  console.log(registrationToken, payload)

  await admin
    .messaging()
    .sendToDevice(registrationToken, payload)
    .then(function (response) {
      console.log('Successfully sent message:', response)
      return true
    })
    .catch(function (error) {
      console.log('Error sending message:', error)
      return false
    })
}

const broadcastMessage = async (tokenList, title, body) => {
  var payload = {
    notification: {
      title: title,
      body: body,
    },
    tokens: tokenList,
  }

  await admin
    .messaging()
    .sendMulticast(payload)
    .then(function (response) {
      console.log('Successfully sent message:', response)
      return true
    })
    .catch(function (error) {
      console.log('Error sending message:', error)
      return false
    })
}

const broadcastPersonal = async (list) => {
  await admin
    .messaging()
    .sendAll(list)
    .then((response) => {
      console.log('Successfully sent message:', response)
      return true
    })
    .catch((e) => {
      console.log('Error sending message:', error)
      return false
    })
}

module.exports = { sendMessage, broadcastMessage, broadcastPersonal }
