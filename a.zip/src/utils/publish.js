class PublishManager {
  constructor(project_id) {
    this.id = project_id
  }
}
