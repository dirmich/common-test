import { createClient } from 'redis'
import cfg from '../config'
import log from './log'

function sleep(mili) {
  return new Promise((resolve, reject) => {
    console.log('sleep')
    setTimeout(resolve, mili)
  })
}
class Redis {
  constructor(host = 'localhost', port = 6379) {
    log.info(`Redis] ${host} ${port}`)
    if (Redis.instance) return Redis.instance
    Redis.instance = this
    this.host = host
    this.port = port
    // this.client = createClient({ socket: { port, host } })
    // this.sub = createClient({ socket: { port, host } })
    let opt = { url: `redis://${host}:${port}` }
    if (cfg.redis_pass) {
      // opt.auth_pass = cfg.redis_pass
      opt = {
        // url: `redis://${cfg.redis_user}:${cfg.redis_pass}@${host}:${port}`,
        password: cfg.redis_pass,
        socket: {
          host,
          port,
          reconnectStratgy() {
            console.log('reconnect')
            return 5000
          },
        },
        // password: 'fF7jsZ3dlfiF4Jtng1g35sJlzQMRkyaG',
        // socket: {
        //   host: 'redis-10646.c267.us-east-1-4.ec2.redns.redis-cloud.com',
        //   port: 10646,
        // },
        // url: `redis://default:fF7jsZ3dlfiF4Jtng1g35sJlzQMRkyaG@redis-10646.c267.us-east-1-4.ec2.redns.redis-cloud.com:10646`,
      }
    }

    this.client = createClient(opt)
    // if (cfg.redis_pass) this.client.auth(cfg.redis_pass)
    // this.sub = createClient(opt)
    // if (cfg.redis_pass) this.sub.auth(cfg.redis_pass)
    this.client.on('error', (err) => {
      log.error('Redis] error: ', err)
    })
    this.client.on('end', () => {
      log.error('Redis] disconnected')
    })
    this.client.on('ready', () => {
      log.error('Redis] ready')
    })
    this.client.on('close', () => {
      log.error('Redis] closed')
    })
    this.client.on('connect', () => {
      log.info('Redis] connected', opt)
      // if (cfg.dev) {
      //   this.client.auth(cfg.redis_pass)
      // }
    })
    this.client.connect()
    // this.sub.connect()
  }

  pub(channel, data) {
    this.client.publish(channel, data, (count) => {
      console.log('pub to ', count)
    })
  }

  async recv(channel) {
    return new Promise((resolve, reject) => {
      this.sub.subscribe(channel)
      const ti = setTimeout(() => this.pub(channel, 'timeout'), 30000)
      this.sub.on('subscribe', (chann, count) => {
        console.log('start sub ', chann, count)
      })
      this.sub.on('message', (chann, data) => {
        console.log('recv data ', chann, data)
        clearTimeout(ti)
        this.sub.unsubscribe(channel)
        console.log('stop sub ', channel)
        switch (data) {
          case 'timeout':
          case 'stop':
            reject(data)
            break
          default:
            resolve(data)
        }
      })
    })
  }

  getClient(duplicate = false) {
    return duplicate
      ? this.client.duplicate()
      : createClient(this.port, this.host)
  }

  async set(key, val) {
    // return new Promise((resolve, reject) => {
    //   this.client.set(
    //     key,
    //     typeof val === 'object' ? JSON.stringify(val) : val,
    //     (e) => {
    //       if (e) reject(e)
    //       resolve()
    //     }
    //   )
    // })
    return await this.client.set(
      key,
      typeof val === 'object' ? JSON.stringify(val) : val
    )
  }

  async get(key) {
    try {
      const d = await this.client.get(key)
      return JSON.parse(d)
    } catch (e) {
      throw e
    }
    // return new Promise((resolve, reject) => {
    //   this.client.get(key, (e, d) => {
    //     if (e) reject(e)
    //     try {
    //       resolve(JSON.parse(d))
    //     } catch (e) {
    //       resolve(d)
    //     }
    //   })
    // })
  }

  async remove(key) {
    return this.client.del(key)
    // return new Promise((resolve, reject) => {
    //   this.client.del(key, (e, n) => {
    //     if (e) reject(e)
    //     resolve(n)
    //   })
    // })
  }

  async getset(key, val) {
    return this.client.getset(key, val)
    // return new Promise((resolve, reject) => {
    //   const r = this.client.getset(key, val, (e, s) => {
    //     if (e) reject(e)
    //     else resolve(s)
    //   })
    //   if (!r) reject('err')
    // })
  }
  async lock() {
    let r = await this.getset('lock', '1')
    let retry = 10
    while (retry > 0 && r > 0) {
      await sleep(500)
      retry--
      r = await this.getset('lock', '1')
    }
    return r == 0
  }

  async unlock() {
    const r = await this.getset('lock', 0)
  }

  loadAll(withValue = false) {
    return new Promise((resolve, reject) => {
      this.client.keys('*', (err, keys) => {
        if (err) reject(err)

        resolve(
          withValue
            ? Promise.all(
                keys.map(async (k) => {
                  return { [k]: await this.get(k) }
                })
              )
            : keys
        )
      })
    })
  }

  removeAll() {
    return new Promise((resolve, reject) => {
      this.client.keys('*', (err, keys) => {
        if (err) reject(err)
        resolve(
          Promise.all(
            keys.map(async (k) => {
              return { [k]: await this.remove(k) }
            })
          )
        )
      })
    })
  }
  match(field, value) {
    return new Promise((resolve, reject) => {})
  }
}

// const instance = new Redis(cfg.redis, cfg.redis_port)
// Object.freeze(instance)
export default new Redis(cfg.redis, cfg.redis_port)
