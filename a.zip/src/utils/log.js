export const log = {
    debug: console.log,
    info: console.log,
    warn: console.log,
    error: console.log,
}

export default log