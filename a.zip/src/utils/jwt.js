import jwt from 'jsonwebtoken'
import cfg from '../config'

class Jwt {
  constructor({ skey, pkey, ...opt }) {
    this.skey = skey
    this.pkey = pkey ? pkey : skey
    this.opt = {
      expiresIn: '365d', // 60000, //60, "2 days", "10h", "7d"
      algorithm: 'HS512', //'HS256',
      // noTimestamp: true,
      issuer: 'auth.highmaru.com',
      ...opt,
    }
    this.verifier = { issuer: this.opt.issuer }
  }

  sign(obj, opt = {}) {
    try {
      return jwt.sign(obj, this.skey, {
        ...this.opt,
        ...this.verifier,
        ...opt,
      })
    } catch (e) {
      console.error(e)
      return null
    }
  }

  verify(token) {
    try {
      return jwt.verify(token, this.pkey, this.verifier)
    } catch (e) {
      console.error(e)
      return null
    }
  }
  decode(token) {
    try {
      return jwt.decode(token, { complete: true })
    } catch (e) {
      console.error(e)
      return null
    }
  }
}

const instance = new Jwt(cfg.jwt)
Object.freeze(instance)
export default instance
