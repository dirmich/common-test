const opts = (c) => ({
  ok: function (obj) {
    return c.json(obj ? obj : {})
  },
  fail: function (msg) {
    return c.json({
      err: true,
      msg: typeof msg === 'object' ? msg : msg.toString(),
    })
  },
  authFail: function () {
    return c.json({ err: true, msg: 'AuthFail' }, 401)
  },
  badParams: function () {
    return c.json({ err: true, msg: 'Bad Params' }, 403)
  },
})

const response = async (c, next) => {
  c.resp = opts(c)
  await next()
}

export default response
