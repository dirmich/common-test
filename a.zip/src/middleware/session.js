import jwt from '../utils/jwt'
import log from '../utils/log'
import redis from '../utils/redis'

export function checkAuth(checkAdmin = false) {
  return async (c, next) => {
    const { resp, req, res } = c
    let token
    const authorization = req.header('authorization')
    if (!authorization) {
      return resp.authFail()
    } else {
      const auth = authorization.split(' ')
      try {
        if (auth.length != 2) {
          throw 'invalid header'
        }
        token = auth[1]
        const a = await jwt.verify(token)
        c.userinfo = await redis.get(token)
        if (!c.userinfo) throw 'no userinfo'
        c.token = token
        if (checkAdmin) {
          if (c.userinfo.type !== 'A' && c.userinfo.type !== 'S')
            throw 'not admin'
        }
        await next()
      } catch (e) {
        console.log('E]', e)
        log.error(`verify: ${e}`)
        if (e === 'no userinfo') await redis.remove(token)
        return resp.authFail()
      }
    }
  }
}
