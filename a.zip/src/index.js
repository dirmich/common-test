import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { logger } from 'hono/logger'
import cfg from './config'
import db from './database'
import response from './middleware/response'
import apis from './routes'
// const log = require('./utils/log')
import log from './utils/log1'
const app = new Hono()

log.debug('db', db !== null)
app.use('*', logger())
app.use(response)
app.use(
  '/*',
  cors({
    origin: (o) => {
      if (!!o && cfg.whitelist.indexOf(o) >= 0) {
        console.log('found', o)
        return o
      }
      // else cb(new Error(`Not allowed:${o}`))
      else false
    },
    credentials: true,
  })
)
app.route('/', apis)

app.notFound((c) => c.text('woops', 404))
app.onError((err, ctx) => {
  console.error(err)
  return ctx.text('try again', 500)
})

// export default app
export default {
  port: cfg.port,
  fetch: app.fetch,
}
