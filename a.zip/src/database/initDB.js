import log from '../utils/log'
import { encodePassword } from '../utils/util'
import User from './model/User'

async function init(db) {
  // const ret = mongoose.connection.db
  const ret = db
    .listCollections({
      name: 'users',
    })
    .next()
    .then(async (info) => {
      const users = await User.find({ type: 'S' })
      if (info === null || users.length === 0) {
        let admin = new User({
          name: 'Super Admin',
          email: 'test@test.com',
          passwd: encodePassword('1234!!'),
          type: 'S',
        })
        await admin.save()
        log.debug('init admin password')
      } else {
        log.debug('already has admin data')
      }
    })
    .catch((e) => {
      log.error(e)
    })
}

export default init
