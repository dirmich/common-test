import mongoose from 'mongoose'
import cfg from '../config'
import log from '../utils/log'
import initDB from './initDB'
// const ctx = require('require-context')
// const models = ctx(__dirname + '/model', true, /\.js/, 'lazy')
// models.keys().forEach((f) => {
//   models(f)
// })

// import './model/Database'
// import './model/Env'
// import './model/Group'
// import './model/Image'
// import './model/Message'
// import './model/Project'
// import './model/User'
import './model/Politician.js'
import './model/Party.js'
import './model/Subcommittee.js'
import './model/Event.js'
import './model/Eventresult.js'
import './model/User.js'
// // import Company from './model/Company'
// // import Controller from './model/Controller'
// // import GPSData from './model/GPSData'
// // import Alarm from './model/Alarm'

const dbSingleton = (() => {
  const db = mongoose.connection
  let instance = null
  const init = async () => {
    mongoose.Promise = Promise
    db.on('error', log.error)
    db.on('connected', () => {
      log.info('MONGO] connected')
    })
    db.on('reconnected', () => {
      log.info('MONGO] reconnected')
    })
    db.on('disconnected', () => {
      log.error('MONGO] disconnected')
    })
    db.on('close', () => {
      log.info('MONGO] closed')
    })
    db.once('open', function () {
      log.info('MONGO] open')
    })
    const url = cfg.mongohost
    const conn = await mongoose.connect(url, {
      // useNewUrlParser: true,
      //   useCreateIndex: true,
      //   useFindAndModify: false,
      // useUnifiedTopology: true,
    })
    log.debug(`url (${url}) connected`)
    await initDB(db.db)
    log.debug('database initialized')
    return {
      conn: conn,
    }
  }

  return {
    createDatabase: () => {
      if (!instance) {
        init().then((r) => {
          instance = r
          return r
        })
      } else return instance
    },
  }
})()

export default dbSingleton.createDatabase()
