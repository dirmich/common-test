import mongoose from 'mongoose'
import apaginate from 'mongoose-aggregate-paginate-v2'
import paginate from 'mongoose-paginate-v2'

const Schema = new mongoose.Schema(
  {
    	name:String,
	nick:String,
	phone:String,
	email:String,
	passwd:String,
	type:String,
	active:Boolean,
	picture:String,
	pushkey:String,

  },
  {
    timestamps: true,
    toJSON: {
      // for external response
      virtuals: true,
      transform: function (doc, ret) {
        delete ret.__v
      },
    },
    toObject: {
      virtuals: true,
      // for internal response
      transform: function (doc, ret) {
        delete ret.__v
      },
    },
  }
)

Schema.statics.byOwner = async function (uid) {
  const list = await this.find({ owner: uid }).sort({ createdAt: -1 })
  return list //as
}


Schema.plugin(apaginate)
Schema.plugin(paginate)
export default mongoose.model('user', Schema)
