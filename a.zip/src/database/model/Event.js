import mongoose from 'mongoose'
import apaginate from 'mongoose-aggregate-paginate-v2'
import paginate from 'mongoose-paginate-v2'

const Schema = new mongoose.Schema(
  {
    	name:String,
	issuer:{
		type: mongoose.Schema.Types.ObjectId,
		ref:'user'
},	desc:String,
	option:[String],
	start:Date,
	end:Date,

  },
  {
    timestamps: true,
    toJSON: {
      // for external response
      virtuals: true,
      transform: function (doc, ret) {
        delete ret.__v
      },
    },
    toObject: {
      virtuals: true,
      // for internal response
      transform: function (doc, ret) {
        delete ret.__v
      },
    },
  }
)

Schema.statics.byOwner = async function (uid) {
  const list = await this.find({ owner: uid }).sort({ createdAt: -1 })
  return list //as
}

Schema.index({ issuer: 1 }, { background: true })
Schema.index({ start: 1 }, { background: true })

Schema.plugin(apaginate)
Schema.plugin(paginate)
export default mongoose.model('event', Schema)
