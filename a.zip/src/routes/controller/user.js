import mongoose from 'mongoose'
import log from '../../utils/log'
import { checkNull } from '../../utils/util'
const User = mongoose.model('user')

const user = {
  list: async ({ req, res, resp, userinfo }) => {
    const all = checkNull(req.query('all'), null)
    const limit = checkNull(req.query('pageSize'), 20)
    const page = checkNull(req.query('page'), 1)
    const sort = checkNull(req.query('sort'), { createdAt: -1 })

    try {
      if (!userinfo) throw 'Auth fail'
      const opt = {}
      
      // if (!userinfo.super) {
      //   if (userinfo.type === 'U') {
      //     opt.owner = userinfo.id
      //   }
      // }

      const list = await User.paginate(opt, {
        page,
        limit,
        sort,
        // populate: ['owner'],
        
      })
      return resp.ok(list)
    } catch (e) {
      return resp.fail(e.toString())
    }
  },
  add: async ({ req, res, resp, userinfo }) => {
    const body = await req.json()
    const owner = checkNull(userinfo?._id, null)
    // const name = checkNull(body.name, null)
    // const description = checkNull(body.description, null)
    // const fields = checkNull(body.fields, null)
    	const name = checkNull(body.name,null)
	const nick = checkNull(body.nick,null)
	const phone = checkNull(body.phone,null)
	const email = checkNull(body.email,null)
	const passwd = checkNull(body.passwd,null)
	const type = checkNull(body.type,null)
	const active = checkNull(body.active,null)
	const picture = checkNull(body.picture,null)
	const pushkey = checkNull(body.pushkey,null)
    // console.log(fields, typeof fields)
    try {
      if (!owner.super) {
        opt.owner = owner
      } else {
      }
      // if (!name && !fields && !owner) {
      if (!name||!email) {  
        return resp.fail('Missing  information')
      }

      // let item = await User.findOne({ owner, name })
      let item = await User.findOne({ owner, name })
      if (item) {
        throw 'Exists'
      }
      const opt = { owner }
      	if (name) opt.name=name
	if (nick) opt.nick=nick
	if (phone) opt.phone=phone
	if (email) opt.email=email
	if (passwd) opt.passwd=passwd
	if (type) opt.type=type
	if (active) opt.active=active
	if (picture) opt.picture=picture
	if (pushkey) opt.pushkey=pushkey

      item = new User(opt)
      await item.save()
      return resp.ok(item)
    } catch (e) {
      log.error(e)
      return resp.fail(e)
    }
  },
  get: async ({ req, res, resp, userinfo }) => {
    const id = checkNull(req.param('id'), null)
    const owner = checkNull(userinfo?._id, null)

    if (!id || !name||!email) return resp.fail('params required')
    try {
      const opt = { _id: id }
      if (!owner.super) {
        opt.owner = owner
      } 
      const item = await User.findOne(opt)
      return resp.ok(item)
    } catch (e) {
      return resp.fail(e.toString())
    }
  },
  update: async ({ req, res, resp, userinfo }) => {
    // const body = await req.parseBody()
    const body = await req.json()
    const _id = checkNull(req.param('id'), null)
    const owner = checkNull(userinfo?._id, null)
    	const name = checkNull(body.name,null)
	const nick = checkNull(body.nick,null)
	const phone = checkNull(body.phone,null)
	const email = checkNull(body.email,null)
	const passwd = checkNull(body.passwd,null)
	const type = checkNull(body.type,null)
	const active = checkNull(body.active,null)
	const picture = checkNull(body.picture,null)
	const pushkey = checkNull(body.pushkey,null)
    // const name = checkNull(body.name, null)
    // const description = checkNull(body.description, null)
    // const fields = checkNull(body.fields, null)


    try {
      if (!_id || !name||!email) {
        return resp.fail('Missing  information')
      }

      const opt = { _id }
      // if (name) opt.name = name
      // if (fields) opt.fields = fields
      // if (description) opt.description = description
      if (!owner.super) {
        opt.owner = owner
      } else {
      }
      	if (name) opt.name=name
	if (nick) opt.nick=nick
	if (phone) opt.phone=phone
	if (email) opt.email=email
	if (passwd) opt.passwd=passwd
	if (type) opt.type=type
	if (active) opt.active=active
	if (picture) opt.picture=picture
	if (pushkey) opt.pushkey=pushkey
      let item = await User.findById(_id)
      if (!item) throw 'not exist'
      // if (!userinfo.super && item.owner.toString() !== owner) throw 'not owner'
      item = await User.findByIdAndUpdate(_id, opt, { new: true })

      return resp.ok(item)
    } catch (e) {
      log.error('app', e)
      return resp.fail(e.toString())
    }
  },
  delete: async ({ req, res, resp, userinfo }) => {
    const _id = checkNull(req.param('id'), null)
    const owner = checkNull(userinfo?._id, null)
    if (!_id) {
      return resp.ok()
    }
    try {
      let item = await User.findOne({ owner, _id })
      if (!item) throw 'not exist'
      // if (!userinfo.super && item.owner.toString() !== owner) throw 'not owner'
      item = await User.findOneAndDelete(_id)
      // console.log('deleted', user)
      return resp.ok()
    } catch (e) {
      return resp.fail(e.toString())
    }
  },
  logout: async ({ req, res, resp, userinfo }) => {
    await redis.remove(req.token)

    return resp.ok()
  },
}

export default user
