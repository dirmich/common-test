import mongoose from 'mongoose'
import log from '../../utils/log'
import { checkNull } from '../../utils/util'
const Subcommittee = mongoose.model('subcommittee')

const subcommittee = {
  list: async ({ req, res, resp, userinfo }) => {
    const all = checkNull(req.query('all'), null)
    const limit = checkNull(req.query('pageSize'), 20)
    const page = checkNull(req.query('page'), 1)
    const sort = checkNull(req.query('sort'), { createdAt: -1 })

    try {
      if (!userinfo) throw 'Auth fail'
      const opt = {}
      
      // if (!userinfo.super) {
      //   if (userinfo.type === 'U') {
      //     opt.owner = userinfo.id
      //   }
      // }

      const list = await Subcommittee.paginate(opt, {
        page,
        limit,
        sort,
        // populate: ['owner'],
        
      })
      return resp.ok(list)
    } catch (e) {
      return resp.fail(e.toString())
    }
  },
  add: async ({ req, res, resp, userinfo }) => {
    const body = await req.json()
    const owner = checkNull(userinfo?._id, null)
    // const name = checkNull(body.name, null)
    // const description = checkNull(body.description, null)
    // const fields = checkNull(body.fields, null)
    	const name = checkNull(body.name,null)
    // console.log(fields, typeof fields)
    try {
      if (!owner.super) {
        opt.owner = owner
      } else {
      }
      // if (!name && !fields && !owner) {
      if (false) {  
        return resp.fail('Missing  information')
      }

      // let item = await Subcommittee.findOne({ owner, name })
      let item = await Subcommittee.findOne({ owner, name })
      if (item) {
        throw 'Exists'
      }
      const opt = { owner }
      	if (name) opt.name=name

      item = new Subcommittee(opt)
      await item.save()
      return resp.ok(item)
    } catch (e) {
      log.error(e)
      return resp.fail(e)
    }
  },
  get: async ({ req, res, resp, userinfo }) => {
    const id = checkNull(req.param('id'), null)
    const owner = checkNull(userinfo?._id, null)

    if (!id || false) return resp.fail('params required')
    try {
      const opt = { _id: id }
      if (!owner.super) {
        opt.owner = owner
      } 
      const item = await Subcommittee.findOne(opt)
      return resp.ok(item)
    } catch (e) {
      return resp.fail(e.toString())
    }
  },
  update: async ({ req, res, resp, userinfo }) => {
    // const body = await req.parseBody()
    const body = await req.json()
    const _id = checkNull(req.param('id'), null)
    const owner = checkNull(userinfo?._id, null)
    	const name = checkNull(body.name,null)
    // const name = checkNull(body.name, null)
    // const description = checkNull(body.description, null)
    // const fields = checkNull(body.fields, null)


    try {
      if (!_id || false) {
        return resp.fail('Missing  information')
      }

      const opt = { _id }
      // if (name) opt.name = name
      // if (fields) opt.fields = fields
      // if (description) opt.description = description
      if (!owner.super) {
        opt.owner = owner
      } else {
      }
      	if (name) opt.name=name
      let item = await Subcommittee.findById(_id)
      if (!item) throw 'not exist'
      // if (!userinfo.super && item.owner.toString() !== owner) throw 'not owner'
      item = await Subcommittee.findByIdAndUpdate(_id, opt, { new: true })

      return resp.ok(item)
    } catch (e) {
      log.error('app', e)
      return resp.fail(e.toString())
    }
  },
  delete: async ({ req, res, resp, userinfo }) => {
    const _id = checkNull(req.param('id'), null)
    const owner = checkNull(userinfo?._id, null)
    if (!_id) {
      return resp.ok()
    }
    try {
      let item = await Subcommittee.findOne({ owner, _id })
      if (!item) throw 'not exist'
      // if (!userinfo.super && item.owner.toString() !== owner) throw 'not owner'
      item = await Subcommittee.findOneAndDelete(_id)
      // console.log('deleted', user)
      return resp.ok()
    } catch (e) {
      return resp.fail(e.toString())
    }
  },
  logout: async ({ req, res, resp, userinfo }) => {
    await redis.remove(req.token)

    return resp.ok()
  },
}

export default subcommittee
