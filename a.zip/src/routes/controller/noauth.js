import axios from 'axios'
import { OAuth2Client } from 'google-auth-library'
import mongoose from 'mongoose'
import tokenManager from '../../utils/jwt'
import log from '../../utils/log'
import redis from '../../utils/redis'

// const User = mongoose.model('user')

export const noauth = {
  login: async ({ req, res, resp, userinfo }) => {
    // const email = checkNull(req.body?.email, null)
    // const passwd = checkNull(req.body?.passwd, null)

    try {
      const body = await req.json()
      const { email, passwd } = body
      // console.log(email, passwd, body)
      // return resp.setHeader('Cache-Control', 'private')
      if (!email || !passwd) {
        return resp.badParams()
      }

      let user = await User.findOne({
        email,
        type: 'U',
        active: true,
      })
      if (!user) {
        user = await User.findOne({
          email,
          type: 'A',
        })
      }
      if (!user) {
        user = await User.findOne({
          email,
          type: 'S',
        })
        if (user && user.type !== 'S') throw 'invalid'
      }
      // console.log('login', user, email, passwd)

      if (user && user.checkPassword(passwd)) {
        // if (user.type !== 'S' && user.type !== 'A')
        //   throw 'User cannot log on web'
        const token = await tokenManager.sign({
          uid: user._id,
        })
        console.log('login token:', token)
        await redis.set(token, {
          // ...user.toObject(),
          ...user.toObject(),
          super: user.type === 'S',
        })
        console.log(user)
        return resp.ok({
          token,
          user,
          // user: user.populate('farm'),
          super: user.type === 'S',
        })
      } else {
        // log.debug(user)
        throw '로그인 실패1'
      }
    } catch (e) {
      log.error(`err ${e.toString()}`)
      return resp.fail(e.toString())
    }
  },
  googlelogin: async ({ req, res, resp, userinfo }) => {
    const body = await req.json()
    const client = new OAuth2Client()
    const { credential, client_id } = body
    // console.log(body, credential, client_id)
    try {
      const ticket = await client.verifyIdToken({
        idToken: credential,
        audience: client_id,
      })
      const payload = ticket.getPayload()
      const userid = payload['sub']
      // console.log('p', payload)
      const { email, name, picture } = payload
      let user = await User.findOne({
        email,
        type: 'U',
        active: true,
      })
      if (!user) {
        user = await User.findOne({
          email,
          type: 'A',
        })
      }
      if (!user) {
        user = await User.findOne({
          email,
          type: 'S',
        })
        if (user && user.type !== 'S') throw 'invalid'
      }
      if (user) {
        const token = await tokenManager.sign({
          uid: user._id,
        })
        await redis.set(token, {
          // ...user.toObject(),
          ...user.toObject(),
          super: user.type === 'S',
        })
        // console.log('olduser', user, token)
        return resp.ok({
          token,
          user,
          // user: user.populate('farm'),
          super: user.type === 'S',
        })
      } else {
        user = new User({
          type: 'U',
          email,
          name,
          picture,
          social: payload,
        })
        await user.save()
        const token = await tokenManager.sign({
          uid: user._id,
        })
        await redis.set(token, {
          // ...user.toObject(),
          ...user.toObject(),
          super: user.type === 'S',
        })
        // console.log('newuser', user, token)
        return resp.ok({ token, user })
      }
    } catch (err) {
      console.log('e', err)
      return resp.fail({ err })
    }
  },
  googleloginWithId: async ({ req, res, resp, userinfo }) => {
    const body = await req.json()
    const client = new OAuth2Client()
    const { access_token } = body
    // console.log(access_token)
    try {
      const r = await axios.get(
        'https://www.googleapis.com/oauth2/v3/userinfo',
        {
          headers: {
            Authorization: `Bearer ${access_token}`,
          },
        }
      )
      const payload = r.data
      // const payload = ticket.getPayload()
      // const userid = payload['sub']
      console.log('p', payload)
      const { email, name, picture } = payload
      let user = await User.findOne({
        email,
        type: 'U',
        active: true,
      })
      if (!user) {
        user = await User.findOne({
          email,
          type: 'A',
        })
      }
      if (!user) {
        user = await User.findOne({
          email,
          type: 'S',
        })
        if (user && user.type !== 'S') throw 'invalid'
      }
      if (user) {
        const token = await tokenManager.sign({
          uid: user._id,
        })
        await redis.set(token, {
          // ...user.toObject(),
          ...user.toObject(),
          super: user.type === 'S',
        })
        // console.log('olduser', user, token)
        return resp.ok({
          token,
          user,
          // user: user.populate('farm'),
          super: user.type === 'S',
        })
      } else {
        user = new User({
          type: 'U',
          email,
          name,
          picture,
          social: payload,
        })
        user = await user.save()
        // console.log('new user', user)
        const token = await tokenManager.sign({
          uid: user._id,
        })
        await redis.set(token, {
          // ...user.toObject(),
          ...user.toObject(),
          super: user.type === 'S',
        })
        // console.log('newuser', user, token)
        return resp.ok({ token, user })
      }
    } catch (err) {
      console.log('e', err)
      return resp.fail({ err })
    }
  },
}

export default {
  noauth,
}
