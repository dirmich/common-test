import mongoose from 'mongoose'
import log from '../../utils/log'
import { checkNull } from '../../utils/util'
const Event = mongoose.model('event')

const event = {
  list: async ({ req, res, resp, userinfo }) => {
    const all = checkNull(req.query('all'), null)
    const limit = checkNull(req.query('pageSize'), 20)
    const page = checkNull(req.query('page'), 1)
    const sort = checkNull(req.query('sort'), { createdAt: -1 })

    try {
      if (!userinfo) throw 'Auth fail'
      const opt = {}
      
      // if (!userinfo.super) {
      //   if (userinfo.type === 'U') {
      //     opt.owner = userinfo.id
      //   }
      // }

      const list = await Event.paginate(opt, {
        page,
        limit,
        sort,
        // populate: ['owner'],
        
      })
      return resp.ok(list)
    } catch (e) {
      return resp.fail(e.toString())
    }
  },
  add: async ({ req, res, resp, userinfo }) => {
    const body = await req.json()
    const owner = checkNull(userinfo?._id, null)
    // const name = checkNull(body.name, null)
    // const description = checkNull(body.description, null)
    // const fields = checkNull(body.fields, null)
    	const name = checkNull(body.name,null)
	const issuer = checkNull(body.issuer,null)
	const desc = checkNull(body.desc,null)
	const option = checkNull(body.option,null)
	const start = checkNull(body.start,null)
	const end = checkNull(body.end,null)
    // console.log(fields, typeof fields)
    try {
      if (!owner.super) {
        opt.owner = owner
      } else {
      }
      // if (!name && !fields && !owner) {
      if (false) {  
        return resp.fail('Missing  information')
      }

      // let item = await Event.findOne({ owner, name })
      let item = await Event.findOne({ owner, name })
      if (item) {
        throw 'Exists'
      }
      const opt = { owner }
      	if (name) opt.name=name
	if (issuer) opt.issuer=issuer
	if (desc) opt.desc=desc
	if (option) opt.option=option
	if (start) opt.start=start
	if (end) opt.end=end

      item = new Event(opt)
      await item.save()
      return resp.ok(item)
    } catch (e) {
      log.error(e)
      return resp.fail(e)
    }
  },
  get: async ({ req, res, resp, userinfo }) => {
    const id = checkNull(req.param('id'), null)
    const owner = checkNull(userinfo?._id, null)

    if (!id || false) return resp.fail('params required')
    try {
      const opt = { _id: id }
      if (!owner.super) {
        opt.owner = owner
      } 
      const item = await Event.findOne(opt)
      return resp.ok(item)
    } catch (e) {
      return resp.fail(e.toString())
    }
  },
  update: async ({ req, res, resp, userinfo }) => {
    // const body = await req.parseBody()
    const body = await req.json()
    const _id = checkNull(req.param('id'), null)
    const owner = checkNull(userinfo?._id, null)
    	const name = checkNull(body.name,null)
	const issuer = checkNull(body.issuer,null)
	const desc = checkNull(body.desc,null)
	const option = checkNull(body.option,null)
	const start = checkNull(body.start,null)
	const end = checkNull(body.end,null)
    // const name = checkNull(body.name, null)
    // const description = checkNull(body.description, null)
    // const fields = checkNull(body.fields, null)


    try {
      if (!_id || false) {
        return resp.fail('Missing  information')
      }

      const opt = { _id }
      // if (name) opt.name = name
      // if (fields) opt.fields = fields
      // if (description) opt.description = description
      if (!owner.super) {
        opt.owner = owner
      } else {
      }
      	if (name) opt.name=name
	if (issuer) opt.issuer=issuer
	if (desc) opt.desc=desc
	if (option) opt.option=option
	if (start) opt.start=start
	if (end) opt.end=end
      let item = await Event.findById(_id)
      if (!item) throw 'not exist'
      // if (!userinfo.super && item.owner.toString() !== owner) throw 'not owner'
      item = await Event.findByIdAndUpdate(_id, opt, { new: true })

      return resp.ok(item)
    } catch (e) {
      log.error('app', e)
      return resp.fail(e.toString())
    }
  },
  delete: async ({ req, res, resp, userinfo }) => {
    const _id = checkNull(req.param('id'), null)
    const owner = checkNull(userinfo?._id, null)
    if (!_id) {
      return resp.ok()
    }
    try {
      let item = await Event.findOne({ owner, _id })
      if (!item) throw 'not exist'
      // if (!userinfo.super && item.owner.toString() !== owner) throw 'not owner'
      item = await Event.findOneAndDelete(_id)
      // console.log('deleted', user)
      return resp.ok()
    } catch (e) {
      return resp.fail(e.toString())
    }
  },
  logout: async ({ req, res, resp, userinfo }) => {
    await redis.remove(req.token)

    return resp.ok()
  },
}

export default event
