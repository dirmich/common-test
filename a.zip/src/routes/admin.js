import { Hono } from 'hono'
import politician from './controller/politician.js'
import party from './controller/party.js'
import subcommittee from './controller/subcommittee.js'
import event from './controller/event.js'
import eventresult from './controller/eventresult.js'
import user from './controller/user.js'

export const app = new Hono()
//==== Route for politician====
app.get('/politician',politician.list)
app.get('/politician/:id',politician.get)
app.post('/politician',politician.add)
app.put('/politician/:id',politician.update)
app.delete('/politician/:id',politician.delete)

//==== Route for party====
app.get('/party',party.list)
app.get('/party/:id',party.get)
app.post('/party',party.add)
app.put('/party/:id',party.update)
app.delete('/party/:id',party.delete)

//==== Route for subcommittee====
app.get('/subcommittee',subcommittee.list)
app.get('/subcommittee/:id',subcommittee.get)
app.post('/subcommittee',subcommittee.add)
app.put('/subcommittee/:id',subcommittee.update)
app.delete('/subcommittee/:id',subcommittee.delete)

//==== Route for event====
app.get('/event',event.list)
app.get('/event/:id',event.get)
app.post('/event',event.add)
app.put('/event/:id',event.update)
app.delete('/event/:id',event.delete)

//==== Route for eventresult====
app.get('/eventresult',eventresult.list)
app.get('/eventresult/:id',eventresult.get)
app.post('/eventresult',eventresult.add)
app.put('/eventresult/:id',eventresult.update)
app.delete('/eventresult/:id',eventresult.delete)

//==== Route for user====
app.get('/user',user.list)
app.get('/user/:id',user.get)
app.post('/user',user.add)
app.put('/user/:id',user.update)
app.delete('/user/:id',user.delete)

app.get('/logout', user.logout)
export default {
  app,
}
