// import { Router } from 'express'
import { Hono } from 'hono'
import { checkAuth } from '../middleware/session'
import admin from './admin'
import base from './controller/noauth'
import user from './user'
// const app = Router()
const app = new Hono()

app.use('/admin/*', checkAuth(true))
app.route('/admin', admin.app)
app.use('/api/*', checkAuth(false))
app.route('/api', user.app)
// app.use('/login', base.noauth.login)
// app.use('/m', checkAuth(), mobile)
// app.use('/image', iup)
app.use('/login', base.noauth.login)
app.use('/loging', base.noauth.googlelogin)
app.use('/loging2', base.noauth.googleloginWithId)

// app.use('/info', user.info)
export default app
